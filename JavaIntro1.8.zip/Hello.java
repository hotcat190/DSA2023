public class Hello {
    public static void main() {
        System.out.println("Doesn't execute");
    }
}
