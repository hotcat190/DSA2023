public class Hi {
    public static void main(String[] args) {
        System.out.println("Hi " + args[0] + ". How are you?");
    }
}
