public class HiThree {
    public static void main(String[] args) {
        System.out.println("Hi " + args[2] + ", " + args[1] + " and " + args[0] + ".");
    }
}
